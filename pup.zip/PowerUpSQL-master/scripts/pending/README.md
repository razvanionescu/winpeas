	### Stand Alone Scripts
	These are scripts that will eventually be turned into PowerUpSQL functions.

	Author: Scott Sutherland	
	Get-SQLCompactQuery.ps1

	Author: Scott Sutherland
	Get-SQLServiceAccountPwHashes.ps1

	Author: Scott Sutherland
	Invoke-SqlServer-Persist-StartupSp.psm1
	
	Author: Scott Sutherland
	Invoke-SqlServer-Persist-TriggerLogon.psm1	

	Author: Antti Rantasaari
	Get-MSSQLCredentialPasswords.psm1
	
	Author: Scott Sutherland
	Invoke-HuntSQLServers.ps1
	
	Author: Scott Sutherland
	SQLC2.ps1
