# Instructions
* Log into a Windows tests system as a local administrator that is connected to a test domain - ideally in an isolution test environment
* Install a local SQL Server 2014 instance
* Enable / install in mixed authentication mode
* Provide the current Windows user with sysadmin privileges
* Run the pesterdb.sql script as a sysadmin in the local SQL Server 2014 instance
* Run the PowerUpSQLTests.ps1 script
